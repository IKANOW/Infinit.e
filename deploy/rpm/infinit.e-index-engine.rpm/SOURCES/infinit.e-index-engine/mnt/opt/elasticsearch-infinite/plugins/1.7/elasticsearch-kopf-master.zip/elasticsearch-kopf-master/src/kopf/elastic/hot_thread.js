function HotThread(header) {
  this.header = header;
  this.subHeader = undefined;
  this.stack = [];
}
